package com.example.railgrip;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

/** Сеть: клиент считает хват сам, а сервер лишь убивает игрока и хранит перчатки. */
public final class Net {
    public static final SimpleNetworkWrapper CH = NetworkRegistry.INSTANCE.newSimpleChannel(RailGrip.MODID);

    public static final DamageSource GRIP_FALL =
            new DamageSource("railgrip_fall").setDamageBypassesArmor().setDamageIsAbsolute();

    private Net() {}

    public static void init() {
        CH.registerMessage(HandlerGlove.class, MsgGlove.class, 0, Side.CLIENT);
        CH.registerMessage(HandlerFall.class, MsgFall.class, 1, Side.SERVER);
        CH.registerMessage(HandlerUnequip.class, MsgUnequip.class, 2, Side.SERVER);
    }

    // ---- сообщения
    public static class MsgGlove implements IMessage {
        long most, least; boolean on;
        public MsgGlove() {}
        public MsgGlove(long most, long least, boolean on) { this.most = most; this.least = least; this.on = on; }
        @Override public void fromBytes(ByteBuf b) { most = b.readLong(); least = b.readLong(); on = b.readBoolean(); }
        @Override public void toBytes(ByteBuf b) { b.writeLong(most); b.writeLong(least); b.writeBoolean(on); }
    }

    public static class MsgFall implements IMessage {
        public MsgFall() {}
        @Override public void fromBytes(ByteBuf b) {}
        @Override public void toBytes(ByteBuf b) {}
    }

    public static class MsgUnequip implements IMessage {
        public MsgUnequip() {}
        @Override public void fromBytes(ByteBuf b) {}
        @Override public void toBytes(ByteBuf b) {}
    }

    // ---- обработчики
    public static class HandlerGlove implements IMessageHandler<MsgGlove, IMessage> {
        @Override
        public IMessage onMessage(MsgGlove m, MessageContext ctx) {
            RailGrip.proxy.handleGlove(m.most, m.least, m.on);
            return null;
        }
    }

    public static class HandlerFall implements IMessageHandler<MsgFall, IMessage> {
        @Override
        public IMessage onMessage(MsgFall m, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            p.getServerWorld().addScheduledTask(new Runnable() {
                @Override public void run() {
                    if (!p.isCreative() && !p.isSpectator()) p.attackEntityFrom(GRIP_FALL, Float.MAX_VALUE);
                }
            });
            return null;
        }
    }

    public static class HandlerUnequip implements IMessageHandler<MsgUnequip, IMessage> {
        @Override
        public IMessage onMessage(MsgUnequip m, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            p.getServerWorld().addScheduledTask(new Runnable() {
                @Override public void run() {
                    if (GloveData.isEquipped(p)) {
                        GloveData.setEquipped(p, false);
                        ItemStack s = new ItemStack(ModItems.GLOVES);
                        if (!p.addItemStackToInventory(s)) p.dropItem(s, false);
                        p.sendStatusMessage(new TextComponentTranslation("msg.railgrip.removed"), true);
                    }
                }
            });
            return null;
        }
    }
}
