package com.example.railgrip;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

/** Определение «это поезд Immersive Railroading» без прямой зависимости от его классов. */
public final class TrainUtil {
    private TrainUtil() {}

    public static boolean isTrain(Entity e) {
        if (e == null || e instanceof EntityPlayer || e.isDead) return false;
        // Immersive Railroading работает на UniversalModCore: его сущности — классы пакета cam72cam
        if (e.getClass().getName().startsWith("cam72cam.")) return true;
        ResourceLocation key = EntityList.getKey(e);
        return key != null && "immersiverailroading".equals(key.getResourceDomain());
    }
}
