package com.example.railgrip;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = RailGrip.MODID, name = "Rail Grip", version = "1.0.0",
        acceptedMinecraftVersions = "[1.12.2]", dependencies = "after:immersiverailroading")
public class RailGrip {
    public static final String MODID = "railgrip";

    @SidedProxy(clientSide = "com.example.railgrip.ClientProxy", serverSide = "com.example.railgrip.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        Net.init();
        MinecraftForge.EVENT_BUS.register(new ServerEvents());
        proxy.preInit();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        proxy.init();
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent e) {
        proxy.postInit();
    }
}
